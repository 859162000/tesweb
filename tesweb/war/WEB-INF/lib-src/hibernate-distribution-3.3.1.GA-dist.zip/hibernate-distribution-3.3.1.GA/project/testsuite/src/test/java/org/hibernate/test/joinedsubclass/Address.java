//$Id: Address.java 4364 2004-08-17 12:10:32Z oneovthafew $
package org.hibernate.test.joinedsubclass;

/**
 * @author Gavin King
 */
public class Address {
	public String address;
	public String zip;
	public String country;
}
