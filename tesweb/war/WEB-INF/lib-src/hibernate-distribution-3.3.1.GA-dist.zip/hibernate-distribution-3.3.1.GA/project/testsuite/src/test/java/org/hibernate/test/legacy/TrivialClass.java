//$Id: TrivialClass.java 4599 2004-09-26 05:18:27Z oneovthafew $
package org.hibernate.test.legacy;

public class TrivialClass extends Top {

}
