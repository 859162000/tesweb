//$Id: Address.java 7119 2005-06-12 22:03:30Z oneovthafew $
package org.hibernate.test.ondelete;

/**
 * @author Gavin King
 */
public class Address {
	public String address;
	public String zip;
	public String country;
}
