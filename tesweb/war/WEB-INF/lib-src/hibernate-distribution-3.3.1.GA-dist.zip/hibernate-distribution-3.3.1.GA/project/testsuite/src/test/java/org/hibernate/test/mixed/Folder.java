//$Id: Folder.java 8670 2005-11-25 17:36:29Z epbernard $

package org.hibernate.test.mixed;


/**
 * @author Gavin King
 */

public class Folder extends Item {

}

