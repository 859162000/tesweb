package org.hibernate.test.legacy;

public interface AbstractProxy extends FooProxy {
	public void setAbstracts(java.util.Set arg0);
	public java.util.Set getAbstracts();
	public void setTime(java.sql.Time arg0);
	public java.sql.Time getTime();
}





