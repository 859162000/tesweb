package org.hibernate.test.any;

/**
 * todo: describe PropertyValue
 *
 * @author Steve Ebersole
 */
public interface PropertyValue {
	public String asString();
}
