package antlr.debug;

public class TraceAdapter implements TraceListener {


	public void doneParsing(TraceEvent e) {}
	public void enterRule(TraceEvent e) {}
	public void exitRule(TraceEvent e) {}
	public void refresh() {}
}
